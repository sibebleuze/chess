var searchData=
[
  ['file',['file',['../structnvwa_1_1new__ptr__list__t.html#a43cb08ce21602c6237e1e761aa59eb05',1,'nvwa::new_ptr_list_t']]]
];
