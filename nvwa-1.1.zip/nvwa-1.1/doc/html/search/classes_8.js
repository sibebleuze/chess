var searchData=
[
  ['mem_5fpool_5fbase',['mem_pool_base',['../classnvwa_1_1mem__pool__base.html',1,'nvwa']]],
  ['mmap_5fline_5freader',['mmap_line_reader',['../classnvwa_1_1mmap__line__reader.html',1,'nvwa']]]
];
