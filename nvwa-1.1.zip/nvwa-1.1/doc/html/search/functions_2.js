var searchData=
[
  ['back',['back',['../classnvwa_1_1fc__queue.html#a3cb1a5b9b02eabe34c00fc3ea5569ac6',1,'nvwa::fc_queue::back()'],['../classnvwa_1_1fc__queue.html#a7d34a2d7a3e4ee43b5f74ab38b053f68',1,'nvwa::fc_queue::back() const']]],
  ['bad_5falloc_5fhandler',['bad_alloc_handler',['../classnvwa_1_1fixed__mem__pool.html#a3a90ff6ea6dbe16930dd22f8e19f8ffe',1,'nvwa::fixed_mem_pool']]],
  ['bool_5farray',['bool_array',['../classnvwa_1_1bool__array.html#a8152d7accea268de044046c812b5548d',1,'nvwa::bool_array::bool_array() noexcept'],['../classnvwa_1_1bool__array.html#ad66170aac111d93214280ee6abd5a93f',1,'nvwa::bool_array::bool_array(size_type size)'],['../classnvwa_1_1bool__array.html#a3377c3e4e217842fc64c9c8f2af88464',1,'nvwa::bool_array::bool_array(const void *ptr, size_type size)'],['../classnvwa_1_1bool__array.html#adb8f4bed770371eb35b3fbd977145471',1,'nvwa::bool_array::bool_array(const bool_array &amp;rhs)']]]
];
