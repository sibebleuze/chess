var searchData=
[
  ['addr',['addr',['../structnvwa_1_1new__ptr__list__t.html#aa59126d4e0da98bc8242297667877772',1,'nvwa::new_ptr_list_t']]],
  ['aligned_5flist_5fitem_5fsize',['ALIGNED_LIST_ITEM_SIZE',['../namespacenvwa.html#adbd676c8217e2c3809b8005675420844',1,'nvwa']]]
];
