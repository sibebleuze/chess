var searchData=
[
  ['wrap_5fargs_5fas_5fpair',['wrap_args_as_pair',['../namespacenvwa.html#a0656844833896c10056f9714fd96f045',1,'nvwa']]],
  ['wrap_5fargs_5fas_5ftuple',['wrap_args_as_tuple',['../namespacenvwa.html#a1de279bf3cbc5408d9c19e1df8d04259',1,'nvwa']]]
];
