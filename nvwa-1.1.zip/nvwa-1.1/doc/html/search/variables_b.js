var searchData=
[
  ['total_5fmem_5falloc',['total_mem_alloc',['../namespacenvwa.html#acfc2fa9c24a7d561348595c8552fbd76',1,'nvwa']]]
];
