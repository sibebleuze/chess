var searchData=
[
  ['new_5fptr_5flist_5ft',['new_ptr_list_t',['../structnvwa_1_1new__ptr__list__t.html',1,'nvwa']]]
];
