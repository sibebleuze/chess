var searchData=
[
  ['new_5fautocheck_5fflag',['new_autocheck_flag',['../namespacenvwa.html#a1aa1dbd7c2ddb5c4d47c4d3cfb0c7429',1,'nvwa']]],
  ['new_5foutput_5ffp',['new_output_fp',['../namespacenvwa.html#a5d893a153e30e12e2ae9c86311eaf4ee',1,'nvwa']]],
  ['new_5foutput_5flock',['new_output_lock',['../namespacenvwa.html#a42b8f85047c4d5474d1aa42fe8edb569',1,'nvwa']]],
  ['new_5fprogname',['new_progname',['../namespacenvwa.html#a434ba338be0258939e6d459eac7028e9',1,'nvwa']]],
  ['new_5fptr_5flist',['new_ptr_list',['../namespacenvwa.html#a01561f0e54269606771ee73f2bba2a14',1,'nvwa']]],
  ['new_5fptr_5flock',['new_ptr_lock',['../namespacenvwa.html#a2c2c859bc51ada6038f5ce780a8ab33d',1,'nvwa']]],
  ['new_5fverbose_5fflag',['new_verbose_flag',['../namespacenvwa.html#a2d9831773d9707c57676688b64a12f24',1,'nvwa']]],
  ['next',['next',['../structnvwa_1_1new__ptr__list__t.html#add9e9a9d95213dec64d39b04b3a3e0d2',1,'nvwa::new_ptr_list_t']]],
  ['npos',['npos',['../classnvwa_1_1bool__array.html#af743e929032796851de110325a490cfc',1,'nvwa::bool_array']]]
];
