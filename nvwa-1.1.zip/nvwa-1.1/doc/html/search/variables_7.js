var searchData=
[
  ['magic',['magic',['../structnvwa_1_1new__ptr__list__t.html#ae911a64a02d8546c122e585decaa957d',1,'nvwa::new_ptr_list_t']]]
];
