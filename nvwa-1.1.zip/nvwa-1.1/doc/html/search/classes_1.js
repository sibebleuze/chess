var searchData=
[
  ['alignment',['alignment',['../structnvwa_1_1fixed__mem__pool_1_1alignment.html',1,'nvwa::fixed_mem_pool']]]
];
