var searchData=
[
  ['dealloc_5fsys',['dealloc_sys',['../classnvwa_1_1mem__pool__base.html#a47149be02bf9c6bb428ab682de4b9228',1,'nvwa::mem_pool_base']]],
  ['deallocate',['deallocate',['../classnvwa_1_1static__mem__pool.html#a7a3d5d1bc4f1bc272f531af6c656eb95',1,'nvwa::static_mem_pool::deallocate()'],['../classnvwa_1_1fixed__mem__pool.html#ab1b93030c9f9f7b876f4090c62834186',1,'nvwa::fixed_mem_pool::deallocate()']]],
  ['debug_5fnew_5fcounter',['debug_new_counter',['../classnvwa_1_1debug__new__counter.html#a75eb5d65ed91a120ac9d7701e1f083be',1,'nvwa::debug_new_counter']]],
  ['debug_5fnew_5frecorder',['debug_new_recorder',['../classnvwa_1_1debug__new__recorder.html#af14cdd86bce9e854d3a3d96d9543b635',1,'nvwa::debug_new_recorder']]],
  ['deinitialize',['deinitialize',['../classnvwa_1_1fixed__mem__pool.html#a1a3e49a912428ef94a7193c4e00c0660',1,'nvwa::fixed_mem_pool']]]
];
