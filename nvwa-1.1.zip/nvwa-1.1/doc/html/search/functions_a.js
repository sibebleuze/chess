var searchData=
[
  ['make_5fcurry',['make_curry',['../namespacenvwa.html#a8abdf0dcfd7a289a4f8da09c195720ce',1,'nvwa::make_curry(std::function&lt; _Rs(_Targs...)&gt; f)'],['../namespacenvwa.html#a8c43fe97fb0fb0bc107b1a8a6611223f',1,'nvwa::make_curry(_Rs(*f)(_Targs...))'],['../namespacenvwa.html#a923a7a96f6f0a4eecf62d625189b0b13',1,'nvwa::make_curry(_Fn &amp;&amp;f)']]],
  ['merge_5fand',['merge_and',['../classnvwa_1_1bool__array.html#acd4127619d1998e63ddb90e679404beb',1,'nvwa::bool_array']]],
  ['merge_5for',['merge_or',['../classnvwa_1_1bool__array.html#a1a7f9d295c2753097a681b1387dabfc9',1,'nvwa::bool_array']]],
  ['mmap_5fline_5freader',['mmap_line_reader',['../classnvwa_1_1mmap__line__reader.html#a9f0f2170494bdeb04c65f39a8f6d1958',1,'nvwa::mmap_line_reader::mmap_line_reader(const char *path, char delimiter=&apos;\n&apos;, strip_type strip=strip_delimiter)'],['../classnvwa_1_1mmap__line__reader.html#a9e59fe37ef9259ad79a50c20c8ffd005',1,'nvwa::mmap_line_reader::mmap_line_reader(int fd, char delimiter=&apos;\n&apos;, strip_type strip=strip_delimiter)']]]
];
