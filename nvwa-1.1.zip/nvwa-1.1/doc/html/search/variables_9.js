var searchData=
[
  ['platform_5fmem_5falignment',['PLATFORM_MEM_ALIGNMENT',['../namespacenvwa.html#a409514d26214cafbf605954dcfab991c',1,'nvwa']]],
  ['prev',['prev',['../structnvwa_1_1new__ptr__list__t.html#a4d1b152f6c1459e363b8db57cf89b9ee',1,'nvwa::new_ptr_list_t']]]
];
