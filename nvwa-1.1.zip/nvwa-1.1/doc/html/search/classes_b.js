var searchData=
[
  ['smart_5fptr',['smart_ptr',['../structnvwa_1_1smart__ptr.html',1,'nvwa']]],
  ['smart_5fptr_3c_20_5ftp_2c_20storage_5fpolicy_3a_3ashared_20_3e',['smart_ptr&lt; _Tp, storage_policy::shared &gt;',['../structnvwa_1_1smart__ptr_3_01__Tp_00_01storage__policy_1_1shared_01_4.html',1,'nvwa']]],
  ['smart_5fptr_3c_20_5ftp_2c_20storage_5fpolicy_3a_3aunique_20_3e',['smart_ptr&lt; _Tp, storage_policy::unique &gt;',['../structnvwa_1_1smart__ptr_3_01__Tp_00_01storage__policy_1_1unique_01_4.html',1,'nvwa']]],
  ['static_5fmem_5fpool',['static_mem_pool',['../classnvwa_1_1static__mem__pool.html',1,'nvwa']]],
  ['static_5fmem_5fpool_5fset',['static_mem_pool_set',['../classnvwa_1_1static__mem__pool__set.html',1,'nvwa']]]
];
