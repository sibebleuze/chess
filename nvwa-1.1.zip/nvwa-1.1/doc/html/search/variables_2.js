var searchData=
[
  ['buffer_5fsize',['BUFFER_SIZE',['../namespacenvwa.html#a9e26fe27ff1ad911aef2104c6c4db799',1,'nvwa']]]
];
