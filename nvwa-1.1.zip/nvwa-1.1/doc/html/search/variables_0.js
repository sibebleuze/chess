var searchData=
[
  ['_5f_5fdebug_5fnew_5fcount',['__debug_new_count',['../namespacenvwa.html#adf39f025b96971f6b77829b27902e72c',1,'nvwa']]],
  ['_5fm_5fnext',['_M_next',['../structnvwa_1_1mem__pool__base_1_1__Block__list.html#af1093457f197f49a618f3865bfaab8d1',1,'nvwa::mem_pool_base::_Block_list']]],
  ['_5fs_5falloc_5fcnt',['_S_alloc_cnt',['../classnvwa_1_1fixed__mem__pool.html#ad8df0551006767c3553e5cdcb4a30ca9',1,'nvwa::fixed_mem_pool']]],
  ['_5fs_5fbit_5fcount',['_S_bit_count',['../classnvwa_1_1bool__array.html#a446b75f342ddfcc9b95904fec8e66101',1,'nvwa::bool_array']]],
  ['_5fs_5fbit_5fordinal',['_S_bit_ordinal',['../classnvwa_1_1bool__array.html#a4b5e2e598b563cd4e7cab4d33b687810',1,'nvwa::bool_array']]],
  ['_5fs_5fcount',['_S_count',['../classnvwa_1_1debug__new__counter.html#a306c9dbde83744d570ac996c7407a5de',1,'nvwa::debug_new_counter']]],
  ['_5fs_5ffirst_5favail_5fptr',['_S_first_avail_ptr',['../classnvwa_1_1fixed__mem__pool.html#add801b699c19b3dce9ba29a6a3870533',1,'nvwa::fixed_mem_pool']]],
  ['_5fs_5fmem_5fpool_5fptr',['_S_mem_pool_ptr',['../classnvwa_1_1fixed__mem__pool.html#aebccaa1c8163f86d5903cdbe8c3354fe',1,'nvwa::fixed_mem_pool']]]
];
