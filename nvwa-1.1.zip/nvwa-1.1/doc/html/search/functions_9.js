var searchData=
[
  ['lift_5foptional',['lift_optional',['../namespacenvwa.html#ade386d629c90f7b27dcdf1f3b5ba887c',1,'nvwa']]]
];
