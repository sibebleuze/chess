var searchData=
[
  ['read',['read',['../classnvwa_1_1file__line__reader.html#a19677d11a6b2cd96735dce611297b7af',1,'nvwa::file_line_reader::read()'],['../classnvwa_1_1mmap__line__reader.html#a49b5109402edb925e161243cee6478e5',1,'nvwa::mmap_line_reader::read()']]],
  ['recycle',['recycle',['../classnvwa_1_1mem__pool__base.html#a7ace64b083ead800b8a8bb57039164d0',1,'nvwa::mem_pool_base::recycle()'],['../classnvwa_1_1static__mem__pool__set.html#a091ed5fd06ce2223c9a5b0ea5350d244',1,'nvwa::static_mem_pool_set::recycle()'],['../classnvwa_1_1static__mem__pool.html#ae10ba9700b9683f087dfcb6c00ec666d',1,'nvwa::static_mem_pool::recycle()']]],
  ['reduce',['reduce',['../namespacenvwa.html#a0ff35a692d498459f54f61ecddb5eaa1',1,'nvwa::reduce(_Fn &amp;&amp;f, const std::tuple&lt; _Targs... &gt; &amp;args, _Rs &amp;&amp;value)'],['../namespacenvwa.html#aa1e48f3d1140e86dc171bbeb3b56772e',1,'nvwa::reduce(_Fn &amp;&amp;f, _Rng &amp;&amp;inputs)'],['../namespacenvwa.html#a91800a2c596cd0a2961c306e7376081e',1,'nvwa::reduce(_Fn &amp;&amp;f, _Rs &amp;&amp;value, _Iter begin, _Iter end)'],['../namespacenvwa.html#a8e857e1cdea13173530b8775107faaab',1,'nvwa::reduce(_Fn &amp;&amp;f, _Rng &amp;&amp;inputs, _Rs &amp;&amp;initval) -&gt; decltype(f(initval, *detail::adl_begin(inputs)))']]],
  ['reference',['reference',['../classnvwa_1_1bool__array.html#a37126d8795a5247f0c2f5a956d408627',1,'nvwa::bool_array']]],
  ['reset',['reset',['../classnvwa_1_1bool__array.html#ae704b46d3c1b008142de5c88a403731c',1,'nvwa::bool_array']]]
];
