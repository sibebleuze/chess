var searchData=
[
  ['size',['size',['../structnvwa_1_1new__ptr__list__t.html#a7d054a6567e8ed57fac7a5208d419fb6',1,'nvwa::new_ptr_list_t']]],
  ['stacktrace',['stacktrace',['../structnvwa_1_1new__ptr__list__t.html#ad7628ed7f0d50bc3d52b9a2e5e536379',1,'nvwa::new_ptr_list_t']]],
  ['stacktrace_5fprint_5fcallback',['stacktrace_print_callback',['../namespacenvwa.html#a4568f4647389b0fd5d3417961247062b',1,'nvwa']]]
];
