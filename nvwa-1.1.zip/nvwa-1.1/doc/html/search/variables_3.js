var searchData=
[
  ['debug_5fnew_5fmagic',['DEBUG_NEW_MAGIC',['../namespacenvwa.html#a8949aa78002ea0ae3b04553654e69798',1,'nvwa']]]
];
