var searchData=
[
  ['_5fblock_5flist',['_Block_list',['../structnvwa_1_1mem__pool__base_1_1__Block__list.html',1,'nvwa::mem_pool_base']]],
  ['_5felement',['_Element',['../classnvwa_1_1bool__array_1_1__Element.html',1,'nvwa::bool_array']]]
];
