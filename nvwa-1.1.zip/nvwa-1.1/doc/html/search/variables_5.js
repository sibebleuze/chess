var searchData=
[
  ['is_5farray',['is_array',['../structnvwa_1_1new__ptr__list__t.html#a9781e640f712f15f854dc19c29136b30',1,'nvwa::new_ptr_list_t']]]
];
