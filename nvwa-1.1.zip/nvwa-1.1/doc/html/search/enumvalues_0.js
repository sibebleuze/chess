var searchData=
[
  ['no_5fstrip_5fdelimiter',['no_strip_delimiter',['../classnvwa_1_1file__line__reader.html#a8563295bc477e6687f097431b19c50e1a9aef9800fc44e7443df4b0ccc262cb2d',1,'nvwa::file_line_reader::no_strip_delimiter()'],['../classnvwa_1_1mmap__line__reader.html#a59d0720b9799c7ad8943701e79c7f3d3a5ea5cfa4ca5c72035f3527d805da8a5c',1,'nvwa::mmap_line_reader::no_strip_delimiter()']]]
];
