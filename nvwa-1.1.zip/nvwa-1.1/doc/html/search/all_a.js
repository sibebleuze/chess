var searchData=
[
  ['magic',['magic',['../structnvwa_1_1new__ptr__list__t.html#ae911a64a02d8546c122e585decaa957d',1,'nvwa::new_ptr_list_t']]],
  ['make_5fcurry',['make_curry',['../namespacenvwa.html#a8abdf0dcfd7a289a4f8da09c195720ce',1,'nvwa::make_curry(std::function&lt; _Rs(_Targs...)&gt; f)'],['../namespacenvwa.html#a8c43fe97fb0fb0bc107b1a8a6611223f',1,'nvwa::make_curry(_Rs(*f)(_Targs...))'],['../namespacenvwa.html#a923a7a96f6f0a4eecf62d625189b0b13',1,'nvwa::make_curry(_Fn &amp;&amp;f)']]],
  ['mem_5fpool_5falignment',['MEM_POOL_ALIGNMENT',['../fixed__mem__pool_8h.html#a8750591dbb5b93d67f2e8df34cc37191',1,'fixed_mem_pool.h']]],
  ['mem_5fpool_5fbase',['mem_pool_base',['../classnvwa_1_1mem__pool__base.html',1,'nvwa']]],
  ['mem_5fpool_5fbase_2ecpp',['mem_pool_base.cpp',['../mem__pool__base_8cpp.html',1,'']]],
  ['mem_5fpool_5fbase_2eh',['mem_pool_base.h',['../mem__pool__base_8h.html',1,'']]],
  ['merge_5fand',['merge_and',['../classnvwa_1_1bool__array.html#acd4127619d1998e63ddb90e679404beb',1,'nvwa::bool_array']]],
  ['merge_5for',['merge_or',['../classnvwa_1_1bool__array.html#a1a7f9d295c2753097a681b1387dabfc9',1,'nvwa::bool_array']]],
  ['mmap_5fline_5freader',['mmap_line_reader',['../classnvwa_1_1mmap__line__reader.html',1,'nvwa::mmap_line_reader'],['../classnvwa_1_1mmap__line__reader.html#a9f0f2170494bdeb04c65f39a8f6d1958',1,'nvwa::mmap_line_reader::mmap_line_reader(const char *path, char delimiter=&apos;\n&apos;, strip_type strip=strip_delimiter)'],['../classnvwa_1_1mmap__line__reader.html#a9e59fe37ef9259ad79a50c20c8ffd005',1,'nvwa::mmap_line_reader::mmap_line_reader(int fd, char delimiter=&apos;\n&apos;, strip_type strip=strip_delimiter)']]],
  ['mmap_5fline_5freader_2ecpp',['mmap_line_reader.cpp',['../mmap__line__reader_8cpp.html',1,'']]],
  ['mmap_5fline_5freader_2eh',['mmap_line_reader.h',['../mmap__line__reader_8h.html',1,'']]]
];
