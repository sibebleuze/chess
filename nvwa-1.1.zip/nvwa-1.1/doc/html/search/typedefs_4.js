var searchData=
[
  ['size_5ftype',['size_type',['../classnvwa_1_1bool__array.html#a65e51ac6f937b94ff9701ad0e7eff83e',1,'nvwa::bool_array']]],
  ['stacktrace_5fprint_5fcallback_5ft',['stacktrace_print_callback_t',['../namespacenvwa.html#a26c6ec05c5861ed7f95ff2602bae3dba',1,'nvwa']]]
];
