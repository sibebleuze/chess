var searchData=
[
  ['storage_5fpolicy',['storage_policy',['../namespacenvwa.html#a93ad754ee9591eafd346f314e7340ea1',1,'nvwa']]],
  ['strip_5ftype',['strip_type',['../classnvwa_1_1file__line__reader.html#a8563295bc477e6687f097431b19c50e1',1,'nvwa::file_line_reader::strip_type()'],['../classnvwa_1_1mmap__line__reader.html#a59d0720b9799c7ad8943701e79c7f3d3',1,'nvwa::mmap_line_reader::strip_type()']]]
];
