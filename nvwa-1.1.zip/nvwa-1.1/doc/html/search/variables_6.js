var searchData=
[
  ['leak_5fwhitelist_5fcallback',['leak_whitelist_callback',['../namespacenvwa.html#ade1f4951d7ccb26f2444fec2a4d03d41',1,'nvwa']]],
  ['line',['line',['../structnvwa_1_1new__ptr__list__t.html#a96f591af9e695b34586979a5e757aa1b',1,'nvwa::new_ptr_list_t']]]
];
