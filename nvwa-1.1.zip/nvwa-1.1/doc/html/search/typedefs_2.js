var searchData=
[
  ['leak_5fwhitelist_5fcallback_5ft',['leak_whitelist_callback_t',['../namespacenvwa.html#a12b153149f9935b64bedcbf989e6dcd0',1,'nvwa']]]
];
