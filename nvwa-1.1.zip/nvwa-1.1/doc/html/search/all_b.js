var searchData=
[
  ['new_5fautocheck_5fflag',['new_autocheck_flag',['../namespacenvwa.html#a1aa1dbd7c2ddb5c4d47c4d3cfb0c7429',1,'nvwa']]],
  ['new_5foutput_5ffp',['new_output_fp',['../namespacenvwa.html#a5d893a153e30e12e2ae9c86311eaf4ee',1,'nvwa']]],
  ['new_5foutput_5flock',['new_output_lock',['../namespacenvwa.html#a42b8f85047c4d5474d1aa42fe8edb569',1,'nvwa']]],
  ['new_5fprogname',['new_progname',['../namespacenvwa.html#a434ba338be0258939e6d459eac7028e9',1,'nvwa']]],
  ['new_5fptr_5flist',['new_ptr_list',['../namespacenvwa.html#a01561f0e54269606771ee73f2bba2a14',1,'nvwa']]],
  ['new_5fptr_5flist_5ft',['new_ptr_list_t',['../structnvwa_1_1new__ptr__list__t.html',1,'nvwa']]],
  ['new_5fptr_5flock',['new_ptr_lock',['../namespacenvwa.html#a2c2c859bc51ada6038f5ce780a8ab33d',1,'nvwa']]],
  ['new_5fverbose_5fflag',['new_verbose_flag',['../namespacenvwa.html#a2d9831773d9707c57676688b64a12f24',1,'nvwa']]],
  ['next',['next',['../structnvwa_1_1new__ptr__list__t.html#add9e9a9d95213dec64d39b04b3a3e0d2',1,'nvwa::new_ptr_list_t']]],
  ['no_5fstrip_5fdelimiter',['no_strip_delimiter',['../classnvwa_1_1file__line__reader.html#a8563295bc477e6687f097431b19c50e1a9aef9800fc44e7443df4b0ccc262cb2d',1,'nvwa::file_line_reader::no_strip_delimiter()'],['../classnvwa_1_1mmap__line__reader.html#a59d0720b9799c7ad8943701e79c7f3d3a5ea5cfa4ca5c72035f3527d805da8a5c',1,'nvwa::mmap_line_reader::no_strip_delimiter()']]],
  ['npos',['npos',['../classnvwa_1_1bool__array.html#af743e929032796851de110325a490cfc',1,'nvwa::bool_array']]],
  ['nvwa',['nvwa',['../namespacenvwa.html',1,'']]]
];
