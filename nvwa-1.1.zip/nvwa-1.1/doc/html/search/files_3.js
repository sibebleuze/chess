var searchData=
[
  ['debug_5fnew_2ecpp',['debug_new.cpp',['../debug__new_8cpp.html',1,'']]],
  ['debug_5fnew_2eh',['debug_new.h',['../debug__new_8h.html',1,'']]]
];
