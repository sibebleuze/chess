var searchData=
[
  ['shared',['shared',['../namespacenvwa.html#a93ad754ee9591eafd346f314e7340ea1a9e81e7b963c71363e2fb3eefcfecfc0e',1,'nvwa']]],
  ['strip_5fdelimiter',['strip_delimiter',['../classnvwa_1_1file__line__reader.html#a8563295bc477e6687f097431b19c50e1a915cfd5108326b80343e972159a274c7',1,'nvwa::file_line_reader::strip_delimiter()'],['../classnvwa_1_1mmap__line__reader.html#a59d0720b9799c7ad8943701e79c7f3d3a5efc5ca54bb848a9a9845c8fd9d1dbab',1,'nvwa::mmap_line_reader::strip_delimiter()']]]
];
