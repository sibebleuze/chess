var searchData=
[
  ['istream_5fline_5freader_2eh',['istream_line_reader.h',['../istream__line__reader_8h.html',1,'']]]
];
