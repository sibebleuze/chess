var searchData=
[
  ['add',['add',['../classnvwa_1_1static__mem__pool__set.html#a8c2da24f1a8b2d67b4417a1a47a740dc',1,'nvwa::static_mem_pool_set']]],
  ['addr',['addr',['../structnvwa_1_1new__ptr__list__t.html#aa59126d4e0da98bc8242297667877772',1,'nvwa::new_ptr_list_t']]],
  ['align',['ALIGN',['../debug__new_8cpp.html#ae5a0704d5128c47e649fab7fae1ceb31',1,'debug_new.cpp']]],
  ['aligned_5flist_5fitem_5fsize',['ALIGNED_LIST_ITEM_SIZE',['../namespacenvwa.html#adbd676c8217e2c3809b8005675420844',1,'nvwa']]],
  ['alignment',['alignment',['../structnvwa_1_1fixed__mem__pool_1_1alignment.html',1,'nvwa::fixed_mem_pool']]],
  ['alloc_5fmem',['alloc_mem',['../namespacenvwa.html#a233a6ba0619ef45883f0ca150d888cc9',1,'nvwa']]],
  ['alloc_5fsys',['alloc_sys',['../classnvwa_1_1mem__pool__base.html#ad6c2f6d2fb006346126209d11097761b',1,'nvwa::mem_pool_base']]],
  ['allocate',['allocate',['../classnvwa_1_1static__mem__pool.html#a8515c99d023c40673c6be35fededcb4d',1,'nvwa::static_mem_pool::allocate()'],['../classnvwa_1_1fixed__mem__pool.html#add6183e7210d4eac76addb437486414b',1,'nvwa::fixed_mem_pool::allocate()']]],
  ['apply',['apply',['../namespacenvwa.html#a15c1afe7519d3a813d20deb255f68969',1,'nvwa::apply(_Fn &amp;&amp;f, _Opt &amp;&amp;... args) -&gt; decltype(has_value(args...), optional&lt; std::decay_t&lt; decltype(f(std::forward&lt; _Opt &gt;(args).value()...))&gt;&gt;())'],['../namespacenvwa.html#aa8ea2e55e4969ca716282e9e863e685e',1,'nvwa::apply(_Fn &amp;&amp;f, _Tuple &amp;&amp;t) -&gt; decltype(detail::tuple_apply_impl(std::forward&lt; _Fn &gt;(f), std::forward&lt; _Tuple &gt;(t), std::make_index_sequence&lt; std::tuple_size&lt; std::decay_t&lt; _Tuple &gt;&gt;::value &gt;()))']]],
  ['at',['at',['../classnvwa_1_1bool__array.html#a4469efe5392e9a27ba8d8cc401aa1937',1,'nvwa::bool_array']]]
];
